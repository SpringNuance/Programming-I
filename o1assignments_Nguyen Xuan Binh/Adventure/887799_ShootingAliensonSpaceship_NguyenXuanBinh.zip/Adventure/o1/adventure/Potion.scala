package o1.adventure

class Potion(var revive: Int) {
   def reviveValue = this.revive
}
