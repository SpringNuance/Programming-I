package o1.adventure

/** Bullets are randomly placed in the basic rooms so the player can collect and charge into their gun */
class Bullets(var numberBullets: Int) {
   def numberOfBullets = this.numberBullets
}
